import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { RoomService, Room, Booking } from '../room.service';

@Component({
  selector: 'app-booking-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './booking-form.component.html',
  styleUrl: './booking-form.component.css'
})
export class BookingFormComponent implements OnInit {

  room!: Room;
  checkIn = '';
  checkOut = '';
  adults = 1;
  children = 0;
  rooms = 1;
  bookedDates: any[] = [];

  guestName = '';
  guestEmail = '';
  step: 1 | 2 | 3 = 1;
  loading = false;
  serverErrorMessage = '';

  constructor(
    private roomService: RoomService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      const user = JSON.parse(userStr);
      this.guestName = user.name || '';
      this.guestEmail = user.email || '';
    }

    const id = this.route.snapshot.paramMap.get('id');
    if (!id) {
      this.router.navigate(['/']);
      return;
    }

    this.roomService.getRoomById(id).subscribe({
      next: (room) => {
        this.room = room;
        this.loadBookedDates(id);
        this.cdr.detectChanges();
      },
      error: () => {
        this.router.navigate(['/']);
      }
    });
  }

  loadBookedDates(roomId: string) {
    this.roomService.getBookedDates(roomId).subscribe({
      next: (dates: any) => {
        this.bookedDates = dates;
      },
      error: (err: any) => {
        console.error('Booked dates error:', err);
      }
    });
  }

  get currentUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  }

  get isEmailMismatch(): boolean {
    if (!this.currentUser || !this.guestEmail) return false;
    return this.guestEmail.toLowerCase() !== this.currentUser.email.toLowerCase();
  }

  get isCapacityExceeded(): boolean {
    const max = this.room?.maxGuests || 0;
    return (Number(this.adults) + Number(this.children)) > max;
  }

  // גטר חדש: בודק בזמן אמת חפיפת תאריכים מול התאריכים שכבר תפוסים בשרת
  get isDateConflict(): boolean {
    if (!this.checkIn || !this.checkOut) return false;

    const chosenIn = new Date(this.checkIn);
    const chosenOut = new Date(this.checkOut);

    return this.bookedDates.some(b => {
      // תומך בשני שמות השדות האפשריים (checkIn או checkInDate) שמגיעים מה-DB
      const bookedIn = new Date(b.checkIn || b.checkInDate);
      const bookedOut = new Date(b.checkOut || b.checkOutDate);

      // תנאי חפיפה: תאריך כניסה מבוקש קטן מתאריך יציאה קיים, ותאריך יציאה מבוקש גדול מתאריך כניסה קיים
      return chosenIn < bookedOut && chosenOut > bookedIn;
    });
  }

  // מעודכן: כפתור ההמשך ייחסם גם במידה ויש התנגשות תאריכים
  get canContinue(): boolean {
    return !!(
      this.guestName &&
      !this.isEmailMismatch &&
      !this.isCapacityExceeded &&
      !this.isDateConflict &&
      this.currentUser &&
      this.checkIn &&
      this.checkOut
    );
  }

  nextStep() {
    if (this.canContinue) {
      this.serverErrorMessage = '';
      this.step = 2;
    } else {
      alert('Please fill in all details correctly and ensure the dates are available.');
    }
  }

  goBack() {
    this.router.navigate(['/room-details', this.room._id]);
  }

  submitBooking() {
    this.loading = true;
    this.serverErrorMessage = '';

    const user = this.currentUser;
    const userId = user ? (user._id || user.id) : null;

    const bookingData: any = {
      room: this.room._id,
      user: userId,
      checkInDate: this.checkIn,
      checkOutDate: this.checkOut,
      roomId: this.room._id,
      guestName: this.guestName,
      guestEmail: this.guestEmail,
      phone: '050-0000000',
      checkIn: this.checkIn,
      checkOut: this.checkOut,
      adults: Number(this.adults) || 1,
      children: Number(this.children) || 0,
      totalPrice: Number(this.room.price) || 0,
      rooms: Number(this.rooms) || 1
    };

    this.roomService.createBooking(bookingData).subscribe({
      next: (res: any) => {
        this.loading = false;
        this.step = 3;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Server rejected booking:', err);
        this.loading = false;

        if (err.error) {
          if (typeof err.error === 'string') {
            this.serverErrorMessage = err.error;
          } else if (err.error.message) {
            this.serverErrorMessage = err.error.message;
          } else {
            this.serverErrorMessage = JSON.stringify(err.error);
          }
        } else {
          this.serverErrorMessage = 'Booking failed. Please try again.';
        }

        this.cdr.detectChanges();
      }
    });
  }
}