import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-all-category',
  imports: [RouterModule],
  templateUrl: './all-category.html',
  styleUrl: './all-category.css',
})
export class AllCategory {
constructor (private router:Router){};
arr:any[]=[
{id:1,name:"villa"},
{id:2,name:"cabnit"},
{id:3,name:"apartment"}];
nav(id:number){
  console.log("click")
this.router.navigate(['rooms',id]);
}
}

