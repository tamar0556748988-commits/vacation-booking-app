import { ChangeDetectorRef, Component, Input, OnInit, signal, Signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReviewService, Review } from '../review.service';

@Component({
  selector: 'app-reviews',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="vv-root">

      <p class="section-title">Guest Reviews ({{ reviews.length }})</p>

      <div class="avg-bar" *ngIf="reviews.length > 0">
        <span class="avg-score">{{ avgRating() }}</span>
        <div class="avg-meta">
          <div class="avg-stars">
            <span *ngFor="let s of starsArray()" class="star"
              [class.filled]="s <= roundedAvg()">
              {{ s <= roundedAvg() ? '★' : '☆' }}
            </span>
          </div>
          <span class="avg-count">{{ reviews.length }} review{{ reviews.length !== 1 ? 's' : '' }}</span>
        </div>
      </div>

      <div class="reviews-list">
        <div class="review-card" *ngFor="let review of reviews">
          <div class="review-header">
            <div class="reviewer">
              <div class="avatar">{{ review.initials }}</div>
              <div class="reviewer-info">
                <p class="reviewer-name">{{ review.name }}</p>
                <div class="review-stars">
                  <span *ngFor="let s of starsArray()" class="star small"
                    [class.filled]="s <= review.rating">
                    {{ s <= review.rating ? '★' : '☆' }}
                  </span>
                </div>
                <p class="review-date">{{ review.date }}</p>
              </div>
            </div>
            <button *ngIf="review.ownedByCurrentUser" class="delete-btn"
              (click)="deleteReview(review._id!)">×</button>
          </div>
          <p class="review-text">{{ review.text }}</p>
        </div>

        <div class="empty-state" *ngIf="reviews.length === 0">
          No reviews yet — be the first!
        </div>
      </div>

      <div class="add-card">
        <p class="add-title">Share your experience</p>

        <div class="star-picker">
          <span *ngFor="let s of starsArray()" class="pick-star"
            [class.filled]="s <= (hoverRating || newRating)"
            (click)="setRating(s)"
            (mouseenter)="setHover(s)"
            (mouseleave)="clearHover()">
            {{ s <= (hoverRating || newRating) ? '★' : '☆' }}
          </span>
          <span class="rating-label">{{ ratingLabel() }}</span>
        </div>

        <textarea class="review-textarea" [(ngModel)]="newText"
          placeholder="What did you love about your stay?"
          maxlength="500" rows="4"></textarea>

        <div class="error-msg" *ngIf="errorMsg">{{ errorMsg }}</div>

        <div class="submit-row">
          <button class="submit-btn" (click)="submitReview()"
            [disabled]="!newRating || !newText.trim() || loading()" >
            {{ loading() ? 'Posting...' : 'Post Review' }}
          </button>
        </div>
      </div>

    </div>
  `,
  styles: [`
    .vv-root { font-family: 'DM Sans','Segoe UI',sans-serif; padding: 2rem 0; }
    .section-title { font-size:13px; font-weight:600; letter-spacing:.08em;
      text-transform:uppercase; color:#1a3a6b; margin:0 0 1.5rem; }
    .avg-bar { display:flex; align-items:center; gap:1.5rem; background:#f7f8fc;
      border-radius:12px; padding:1.25rem 1.5rem; margin-bottom:1.75rem;
      border:0.5px solid #e0e4f0; }
    .avg-score { font-size:42px; font-weight:600; color:#1a3a6b; line-height:1; }
    .avg-meta { display:flex; flex-direction:column; gap:4px; }
    .avg-stars { display:flex; gap:3px; }
    .avg-count { font-size:13px; color:#6b7280; }
    .star { font-size:18px; color:#d0d5e8; }
    .star.filled { color:#e6a817; }
    .star.small { font-size:14px; }
    .reviews-list { display:flex; flex-direction:column; gap:1rem; margin-bottom:1.75rem; }
    .review-card { background:#fff; border:0.5px solid #e0e4f0;
      border-radius:12px; padding:1.25rem 1.5rem; }
    .review-header { display:flex; justify-content:space-between;
      align-items:flex-start; margin-bottom:.75rem; }
    .reviewer { display:flex; align-items:center; gap:.75rem; }
    .avatar { width:38px; height:38px; border-radius:50%; background:#1a3a6b;
      display:flex; align-items:center; justify-content:center; font-size:14px;
      font-weight:600; color:#fff; flex-shrink:0; }
    .reviewer-name { font-size:14px; font-weight:500; color:#1a3a6b; margin:0; }
    .review-stars { display:flex; gap:2px; margin:2px 0; }
    .review-date { font-size:12px; color:#9ca3af; margin:0; }
    .review-text { font-size:14px; color:#374151; line-height:1.65; margin:0; }
    .delete-btn { background:none; border:none; cursor:pointer; color:#9ca3af;
      font-size:20px; padding:2px 6px; border-radius:6px; line-height:1;
      transition:background .15s,color .15s; }
    .delete-btn:hover { background:#fee2e2; color:#dc2626; }
    .empty-state { text-align:center; padding:2rem; color:#9ca3af; font-size:14px; }
    .add-card { background:#fff; border:0.5px solid #e0e4f0;
      border-radius:12px; padding:1.25rem 1.5rem; }
    .add-title { font-size:14px; font-weight:500; color:#1a3a6b; margin:0 0 1rem; }
    .star-picker { display:flex; align-items:center; gap:5px; margin-bottom:.9rem; }
    .pick-star { font-size:26px; cursor:pointer; color:#d0d5e8;
      transition:transform .15s; user-select:none; }
    .pick-star.filled { color:#e6a817; }
    .pick-star:hover { transform:scale(1.15); }
    .rating-label { font-size:12px; color:#6b7280; margin-left:6px; }
    .review-textarea { width:100%; box-sizing:border-box; border:0.5px solid #cdd2e8;
      border-radius:8px; padding:.7rem .9rem; font-size:14px; font-family:inherit;
      color:#1a3a6b; resize:vertical; outline:none; transition:border .15s; }
    .review-textarea:focus { border-color:#1a3a6b; }
    .review-textarea::placeholder { color:#b0b7ce; }
    .error-msg { color:#dc2626; font-size:13px; margin-bottom:.5rem; }
    .submit-row { display:flex; justify-content:flex-end; margin-top:.75rem; }
    .submit-btn { background:#1a3a6b; color:#fff; border:none; border-radius:8px;
      padding:.6rem 1.4rem; font-size:14px; font-weight:500; font-family:inherit;
      cursor:pointer; transition:background .15s,opacity .15s; }
    .submit-btn:hover:not(:disabled) { background:#14305a; }
    .submit-btn:disabled { opacity:.55; cursor:default; }
  `]
})
export class ReviewsComponent implements OnInit {
  @Input() roomId: string = '';
  @Input() currentUserId: string | null = null;

  reviews: Review[] = [];
  newRating = 0;
  hoverRating = 0;
  newText = '';
   loading = signal(false);
  errorMsg = '';

  private readonly LABELS = ['', 'Poor', 'Fair', 'Good', 'Very good', 'Excellent'];

  constructor(private reviewService: ReviewService, private cdr:ChangeDetectorRef) {}

  ngOnInit(): void {
    if (!this.roomId) return;
    this.reviewService.getByRoom(this.roomId).subscribe({
      next: (data: Review[]) => {
        this.reviews = data.map((r: Review) => ({
          ...r,
          ownedByCurrentUser: r.userId === this.currentUserId
        }));
      },
      error: (err: Error) => console.error('Failed to load reviews', err)
    });
  }

  starsArray(): number[] { return [1, 2, 3, 4, 5]; }

  avgRating(): string {
    if (!this.reviews.length) return '0.0';
    const sum = this.reviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / this.reviews.length).toFixed(1);
  }

  roundedAvg(): number { return Math.round(parseFloat(this.avgRating())); }
  setRating(v: number): void { this.newRating = v; }
  setHover(v: number): void { this.hoverRating = v; }
  clearHover(): void { this.hoverRating = 0; }
  ratingLabel(): string { return this.LABELS[this.hoverRating || this.newRating] || 'Select a rating'; }

  submitReview(): void {
    if (!this.newRating || !this.newText.trim()) return;
    if (!this.currentUserId) {
      this.errorMsg = 'Please log in to post a review.';
      return;
    }
    this.loading.set(true);
    this.errorMsg = '';

    this.reviewService.add({
      roomId: this.roomId,
      userId: this.currentUserId,
      text: this.newText.trim(),
      rating: this.newRating
    }).subscribe({
      next: (saved: Review) => {
        this.reviews = [{ ...saved, ownedByCurrentUser: true }, ...this.reviews];
        this.newRating = 0;
        this.newText = '';
        this.loading.set(false);
        // this.cdr.detectChanges();
        // this.cdr.markForCheck();
      },
      error: (err: Error) => {
        this.errorMsg = 'Failed to post review. Try again.';
        console.error(err);
        this.loading.set(false);
      }
    });
  }

  deleteReview(id: string): void {
    this.reviewService.delete(id).subscribe({
      next: () => this.reviews = this.reviews.filter(r => r._id !== id),
      error: (err: Error) => console.error('Failed to delete', err)
    });
  }
}